<?php
/*
Plugin Name: Webpage Analytics
Plugin URI: https://bisiesto.es/
Description: A plugin used to send events to Google Analytics
Author: Bisiesto Estudio
Author URI: https://bisiesto.es/
version: 1.0
*/

add_action('wp_enqueue_scripts','webpage_analytics_init');

function webpage_analytics_init() {
    wp_register_script( 'webpage_analytics.js', plugin_dir_url( __FILE__ ) . 'assets/js/webpage_analytics.js', array( 'jquery' ), '1.0' );
    wp_enqueue_script( 'webpage_analytics.js' );
}