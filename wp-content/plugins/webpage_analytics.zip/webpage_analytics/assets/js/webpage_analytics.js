jQuery( document ).ready(function() {
    registerGoogleAnalytics();

    $( ".navbar-inverse .navbar-nav > li > a" ).on( "click", onPressMenuItem);
});
function registerGoogleAnalytics(){
    console.log('Registering to Google Analytics...');
    window.dataLayer = window.dataLayer || [];
    /*
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-XXXX');
     */
}

function onPressMenuItem(event){

    console.log(event);

    sendToAnalytics(
    'custom_click',
    'header',
    'menu',
    'quienes_somos',
    '',
    'Quiénes somos',
    );
}

function sendToAnalytics(
    event,
    event_category,
    event_action,
    event_label,
    cta_link,
    clicked_text,
    ko_cause = null
){
    let page_location = window.location.href;
    let page_referrer = ''; // TODO: Ask exactly how to get the page referrer
    let page_title = document.title;
    let screen_resolution = window.screen.width+"x"+window.screen.height;

    let level = "nivel1"; // TODO: Ask exactly
    let page_type = "Particulares"; // TODO: Ask exactly

    let information = {
        'page_location': page_location,
        'page_referrer': page_referrer,
        'page_title': page_title,
        'screen_resolution': screen_resolution,
        'level': level,
        'page_type': page_type,
        'event': event,
        'event_category': event_category,
        'event_action': event_action,
        'event_label': event_label,
        'cta_link': cta_link,
        'clicked_text': clicked_text,
    }

    if(ko_cause != null){
        information.ko_cause = ko_cause;
    }

    console.log(information);

    // dataLayer.push(information);
}
